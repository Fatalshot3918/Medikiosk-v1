CREATE DATABASE IF NOT EXISTS Medikiosk;
USE Medikiosk;

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS patients (
    Patient_Id      INT AUTO_INCREMENT PRIMARY KEY,
    First_Name      VARCHAR(50) NOT NULL,
    Last_Name       VARCHAR(50),
    Date_Of_Birth   DATE,
    Gender          VARCHAR(20),
    Phone           VARCHAR(15),
    Email           VARCHAR(100),
    Address         VARCHAR(255),
    Blood_Group     VARCHAR(5),
    Created_At      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS patient_identifiers (
    Identifier_Id   INT AUTO_INCREMENT PRIMARY KEY,
    Patient_Id      INT NOT NULL,
    Id_Type         ENUM('AADHAAR', 'ABHA') NOT NULL,
    Lookup_Id       VARCHAR(64) NOT NULL,
    Created_At      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Patient_Id) REFERENCES patients(Patient_Id)
        ON DELETE CASCADE,
    UNIQUE KEY uq_id_type_lookup (Id_Type, Lookup_Id),
    INDEX idx_patient_lookup (Patient_Id)
    );
    
CREATE TABLE IF NOT EXISTS doctors (
    Doctor_Id       INT AUTO_INCREMENT PRIMARY KEY,
    Name            VARCHAR(100) NOT NULL,
    Specialization  VARCHAR(100),
    Created_At      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS consultations (
    Case_Id                 INT AUTO_INCREMENT PRIMARY KEY,
    Patient_Id              INT NOT NULL,
    Doctor_Id               INT NULL,
    Status                  ENUM('AWAITING_DOCTOR', 'UNDER_CONSULTATION', 'COMPLETED')
                             NOT NULL DEFAULT 'AWAITING_DOCTOR',
    Checked_In_At           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    History_Submitted_At    TIMESTAMP NULL,
    Diagnosis_Submitted_At  TIMESTAMP NULL,
    Completed_At            TIMESTAMP NULL,
    FOREIGN KEY (Patient_Id) REFERENCES patients(Patient_Id)
        ON DELETE CASCADE,
    FOREIGN KEY (Doctor_Id) REFERENCES doctors(Doctor_Id)
        ON DELETE SET NULL,
    INDEX idx_status_checkin (Status, Checked_In_At),
    INDEX idx_patient (Patient_Id)
);

CREATE TABLE IF NOT EXISTS consultation_history (
    History_Id                      INT AUTO_INCREMENT PRIMARY KEY,
    Case_Id                         INT NOT NULL UNIQUE,

    -- Shared by both patient submission and doctor view (12)
    chief_complaint                 TEXT,
    duration                        VARCHAR(100),
    symptom_changes                 TEXT,
    past_medical_history            TEXT,
    hospital_admissions             TEXT,
    surgeries                       TEXT,
    current_medications             TEXT,
    allergies                       TEXT,
    family_history                  TEXT,
    diet                            TEXT,
    physical_activity               TEXT,
    lifestyle_information           TEXT,

    -- Patient-only fields (7) — not shown in current doctor UI (Inconsistency D)
    sleep                           TEXT,
    mental_emotional_wellbeing      TEXT,
    immunization_history            TEXT,
    recent_medical_tests            TEXT,
    additional_health_information   TEXT,
    previous_diagnoses              TEXT,
    patient_concerns                TEXT,

    -- Doctor-only fields (8) — nullable, not sent by patient form (Inconsistency C)
    symptom_severity                VARCHAR(50)  NULL,
    symptoms_description            TEXT NULL,
    relieving_factors               TEXT NULL,
    aggravating_factors             TEXT NULL,
    other_symptoms                  TEXT NULL,
    previous_similar_symptoms       TEXT NULL,
    medication_reactions            TEXT NULL,
    additional_family_information   TEXT NULL,

    Created_At                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (Case_Id) REFERENCES consultations(Case_Id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS consultation_diagnoses (
    Diagnosis_Id    INT AUTO_INCREMENT PRIMARY KEY,
    Case_Id         INT NOT NULL UNIQUE,
    Doctor_Id       INT NULL,
    Diagnosis       TEXT NOT NULL,
    Doctor_Notes    TEXT,
    Treatment       TEXT,
    Submitted_At    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Case_Id) REFERENCES consultations(Case_Id)
        ON DELETE CASCADE,
    FOREIGN KEY (Doctor_Id) REFERENCES doctors(Doctor_Id)
        ON DELETE SET NULL
);

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO patients (First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES ('Asha', 'Verma', '1990-04-12', 'Female', '9876543210', 'asha.verma@example.com', 'Pune, MH', 'B+');

SET @test_patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers (Patient_Id, Id_Type, Lookup_Id)
VALUES (@test_patient_id, 'AADHAAR', '123412341234');

INSERT INTO doctors (Name, Specialization)
VALUES ('Dr. Rohan Mehta', 'General Medicine');

SET @test_doctor_id = LAST_INSERT_ID();

INSERT INTO consultations (Patient_Id, Status, Checked_In_At)
VALUES (@test_patient_id, 'AWAITING_DOCTOR', NOW());

SET @test_case_id = LAST_INSERT_ID();

INSERT INTO consultation_history (
    Case_Id, chief_complaint, duration, symptom_changes, past_medical_history,
    current_medications, allergies, surgeries, hospital_admissions,
    family_history, lifestyle_information, diet, physical_activity,
    sleep, mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
) VALUES (
    @test_case_id, 'Persistent headache', '3 days', 'Getting worse in the evening',
    'None reported', 'Paracetamol as needed', 'No known allergies', 'None',
    'None', 'No family history of migraines', 'Mostly sedentary', 'Regular meals',
    'Light exercise 2x/week', '6 hours/night', 'Mildly stressed at work',
    'Up to date', 'None recent', 'None', 'None', 'Wants to rule out migraine'
);

UPDATE consultations SET History_Submitted_At = NOW() WHERE Case_Id = @test_case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Rajesh', 'Kumar', '1985-08-21', 'Male', '9876543211',
 'rajesh.kumar@example.com', 'Panaji, Goa', 'O+');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'AADHAAR', '123412341235');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id,
    chief_complaint,
    duration,
    symptom_changes,
    past_medical_history,
    current_medications,
    allergies,
    surgeries,
    hospital_admissions,
    family_history,
    lifestyle_information,
    diet,
    physical_activity,
    sleep,
    mental_emotional_wellbeing,
    immunization_history,
    recent_medical_tests,
    additional_health_information,
    previous_diagnoses,
    patient_concerns
)
VALUES
(
    @case_id,
    'Persistent cough',
    '2 weeks',
    'Cough has become more frequent at night',
    'No major medical conditions',
    'None',
    'No known allergies',
    'None',
    'None',
    'Father had asthma',
    'Non-smoker',
    'Mixed diet',
    'Walks 30 minutes daily',
    '7 hours/night',
    'No major concerns',
    'Up to date',
    'Chest X-ray not performed',
    'Occasional throat irritation',
    'None',
    'Worried about prolonged cough'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Priya', 'Nair', '1997-03-14', 'Female', '9876543212',
 'priya.nair@example.com', 'Margao, Goa', 'A+');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'ABHA', '234523452345');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Frequent headaches',
    '1 month',
    'Headaches occur more often after long periods of screen use',
    'No known chronic illness',
    'Occasional paracetamol',
    'No known allergies',
    'None',
    'None',
    'Mother has migraine history',
    'Works long hours at a computer',
    'Mostly home-cooked meals',
    'Light exercise twice a week',
    '6 hours/night',
    'Reports moderate work stress',
    'Up to date',
    'Routine blood test was normal',
    'Eye strain during computer use',
    'None',
    'Wants to know whether headaches are migraine-related'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Amit', 'Patil', '1978-11-02', 'Male', '9876543213',
 'amit.patil@example.com', 'Vasco da Gama, Goa', 'B+');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'AADHAAR', '123412341236');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Knee pain',
    '3 months',
    'Pain increases after climbing stairs',
    'Mild hypertension',
    'Amlodipine',
    'No known allergies',
    'None',
    'None',
    'Father had arthritis',
    'Sedentary office job',
    'High-salt diet',
    'Limited physical activity',
    '6 hours/night',
    'Generally stable',
    'Up to date',
    'Blood pressure checked recently',
    'Occasional stiffness in the morning',
    'Hypertension',
    'Wants to know the cause of knee pain'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Sneha', 'Desai', '1992-07-19', 'Female', '9876543214',
 'sneha.desai@example.com', 'Mapusa, Goa', 'O-');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'ABHA', '234523452346');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Stomach discomfort',
    '10 days',
    'Discomfort is worse after heavy meals',
    'No significant medical history',
    'None',
    'Allergic to penicillin',
    'None',
    'None',
    'No major family history',
    'Occasionally skips meals',
    'Spicy food frequently',
    'Moderate exercise',
    '7 hours/night',
    'Mild stress',
    'Up to date',
    'No recent tests',
    'Occasional acidity',
    'None',
    'Wants dietary advice'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Vikram', 'Singh', '1969-01-25', 'Male', '9876543215',
 'vikram.singh@example.com', 'Ponda, Goa', 'AB+');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'AADHAAR', '123412341237');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Shortness of breath during walking',
    '2 months',
    'Breathlessness occurs after moderate physical activity',
    'Type 2 diabetes',
    'Metformin',
    'No known allergies',
    'None',
    'Hospitalized once for pneumonia',
    'Mother had diabetes',
    'Low physical activity',
    'Diabetic diet inconsistently followed',
    'Minimal exercise',
    '6 hours/night',
    'Concerned about health',
    'Up to date',
    'Blood sugar checked last week',
    'Occasional fatigue',
    'Type 2 diabetes',
    'Wants to understand the breathing problem'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Neha', 'Fernandes', '2001-09-08', 'Female', '9876543216',
 'neha.fernandes@example.com', 'Calangute, Goa', 'A-');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'ABHA', '234523452347');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Sore throat',
    '5 days',
    'Pain is gradually improving',
    'No significant medical history',
    'Cough syrup',
    'No known allergies',
    'None',
    'None',
    'No significant family history',
    'Non-smoker',
    'Balanced diet',
    'Regular exercise',
    '8 hours/night',
    'No significant stress',
    'Up to date',
    'None',
    'Mild nasal congestion',
    'None',
    'Wants relief from throat pain'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Arjun', 'Rao', '1988-12-17', 'Male', '9876543217',
 'arjun.rao@example.com', 'Porvorim, Goa', 'O+');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'AADHAAR', '123412341238');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Lower back pain',
    '4 weeks',
    'Pain increases after prolonged sitting',
    'Previous minor back strain',
    'Occasional painkiller',
    'No known allergies',
    'None',
    'None',
    'No major family history',
    'Desk job',
    'Mixed diet',
    'Little exercise',
    '6 to 7 hours/night',
    'Moderate work stress',
    'Up to date',
    'None recent',
    'Pain sometimes extends to hip',
    'Previous back strain',
    'Wants advice on preventing recurrence'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Kavita', 'Joshi', '1975-05-29', 'Female', '9876543218',
 'kavita.joshi@example.com', 'Bicholim, Goa', 'B+');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'ABHA', '234523452348');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Joint stiffness',
    '6 months',
    'Stiffness is worse in the morning',
    'Osteoarthritis',
    'Paracetamol occasionally',
    'No known allergies',
    'Knee surgery 5 years ago',
    'None recently',
    'Mother had arthritis',
    'Moderately active',
    'Balanced diet',
    'Light walking',
    '7 hours/night',
    'Generally stable',
    'Up to date',
    'X-ray performed 3 months ago',
    'Difficulty climbing stairs',
    'Osteoarthritis',
    'Wants to know about treatment options'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;

INSERT INTO patients
(First_Name, Last_Name, Date_Of_Birth, Gender, Phone, Email, Address, Blood_Group)
VALUES
('Rohit', 'Naik', '1995-10-11', 'Male', '9876543219',
 'rohit.naik@example.com', 'Quepem, Goa', 'A+');

SET @patient_id = LAST_INSERT_ID();

INSERT INTO patient_identifiers
(Patient_Id, Id_Type, Lookup_Id)
VALUES
(@patient_id, 'AADHAAR', '123412341239');

INSERT INTO consultations
(Patient_Id, Status, Checked_In_At)
VALUES
(@patient_id, 'AWAITING_DOCTOR', NOW());

SET @case_id = LAST_INSERT_ID();

INSERT INTO consultation_history
(
    Case_Id, chief_complaint, duration, symptom_changes,
    past_medical_history, current_medications, allergies,
    surgeries, hospital_admissions, family_history,
    lifestyle_information, diet, physical_activity, sleep,
    mental_emotional_wellbeing, immunization_history,
    recent_medical_tests, additional_health_information,
    previous_diagnoses, patient_concerns
)
VALUES
(
    @case_id,
    'Seasonal allergy symptoms',
    '3 weeks',
    'Symptoms worsen in the morning',
    'Allergic rhinitis',
    'Antihistamine when required',
    'Dust allergy',
    'None',
    'None',
    'Sibling has similar allergies',
    'Outdoor worker',
    'Regular mixed diet',
    'Physically active',
    '7 hours/night',
    'No significant concerns',
    'Up to date',
    'None recent',
    'Frequent sneezing and watery eyes',
    'Allergic rhinitis',
    'Wants better control of allergy symptoms'
);

UPDATE consultations
SET History_Submitted_At = NOW()
WHERE Case_Id = @case_id;


