"""
app.py — MediKiosk Flask integration layer.

Connects the existing patient and doctor frontends to the existing
MySQL schema. Does not redesign either frontend's API contract or
the database schema — see the accompanying integration analysis.

Endpoints (exact contracts as found in the existing frontend JS):
    POST /api/patient/lookup
    POST /api/patient/case-history
    POST /api/patient/new-session
    GET  /api/doctor/patients
    GET  /api/doctor/patient/<lookup_id>/history
    POST /api/doctor/patient/<lookup_id>/diagnosis
"""

import logging
from datetime import date

import mysql.connector
from flask import Flask, jsonify, request
from flask_cors import CORS

from db import DEFAULT_DOCTOR_ID, db_cursor

app = Flask(__name__)
CORS(app)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("medikiosk")


# ============================================================
# CONSTANTS — field lists shared with the existing frontends
# ============================================================

# Exactly the 19 fields the patient form sends (patient script.js
# `formFields`). These already match consultation_history column
# names 1:1 — no renaming required.
PATIENT_HISTORY_FIELDS = [
    "chief_complaint",
    "duration",
    "symptom_changes",
    "past_medical_history",
    "current_medications",
    "allergies",
    "surgeries",
    "hospital_admissions",
    "family_history",
    "lifestyle_information",
    "diet",
    "physical_activity",
    "sleep",
    "mental_emotional_wellbeing",
    "immunization_history",
    "recent_medical_tests",
    "additional_health_information",
    "previous_diagnoses",
    "patient_concerns",
]

# The 8 doctor-only columns. Never written by this backend (no
# frontend call collects them). Returned as null until unset.
DOCTOR_ONLY_HISTORY_FIELDS = [
    "symptom_severity",
    "symptoms_description",
    "relieving_factors",
    "aggravating_factors",
    "other_symptoms",
    "previous_similar_symptoms",
    "medication_reactions",
    "additional_family_information",
]

VALID_ID_TYPES = {"AADHAAR", "ABHA"}

# Case statuses reachable in the current frontend's workflow: there
# is no claim step, so a case is either waiting or done.
ACTIVE_CASE_STATUS = "AWAITING_DOCTOR"


# ============================================================
# RESPONSE HELPERS
# ============================================================

def error_response(message, status):
    return jsonify({"success": False, "message": message}), status


def internal_error_response():
    """
    Generic response for unexpected DB/server errors. Never include
    the raw exception text in what's sent to the client.
    """
    return error_response("Something went wrong. Please try again.", 500)


def compute_age(date_of_birth):
    if not date_of_birth:
        return None
    today = date.today()
    years = today.year - date_of_birth.year
    if (today.month, today.day) < (date_of_birth.month, date_of_birth.day):
        years -= 1
    return years


def build_patient_name(first_name, last_name):
    parts = [p for p in [first_name, last_name] if p]
    return " ".join(parts) if parts else "Patient"


# ============================================================
# SHARED DB LOOKUPS
# ============================================================

def find_patient_by_identifier(cursor, lookup_id, id_type=None):
    """
    Resolve a patient row from an Aadhaar/ABHA identifier.

    When id_type is given (patient-side calls always send both
    lookup_id and id_type), match the exact (Id_Type, Lookup_Id)
    unique key.

    When id_type is not given (doctor-side URLs only carry the
    identifier value), match on Lookup_Id alone. This assumes an
    Aadhaar number and an ABHA number never collide in value, which
    holds for the seeded data and is a reasonable hackathon-scope
    assumption given the two identifier formats come from different
    national registries.
    """
    if id_type:
        cursor.execute(
            """
            SELECT p.*
            FROM patients p
            JOIN patient_identifiers pi ON pi.Patient_Id = p.Patient_Id
            WHERE pi.Id_Type = %s AND pi.Lookup_Id = %s
            LIMIT 1
            """,
            (id_type, lookup_id),
        )
    else:
        cursor.execute(
            """
            SELECT p.*
            FROM patients p
            JOIN patient_identifiers pi ON pi.Patient_Id = p.Patient_Id
            WHERE pi.Lookup_Id = %s
            LIMIT 1
            """,
            (lookup_id,),
        )
    return cursor.fetchone()


def find_active_case_for_patient(cursor, patient_id):
    """
    Find the patient's currently active case.

    The doctor frontend has no claim/assignment step, so the only
    state a case can be in before diagnosis is AWAITING_DOCTOR. If a
    claim workflow is added later, broaden this to
    Status IN ('AWAITING_DOCTOR', 'UNDER_CONSULTATION').
    """
    cursor.execute(
        """
        SELECT *
        FROM consultations
        WHERE Patient_Id = %s AND Status = %s
        ORDER BY Checked_In_At DESC
        LIMIT 1
        """,
        (patient_id, ACTIVE_CASE_STATUS),
    )
    return cursor.fetchone()


# ============================================================
# PATIENT ENDPOINTS
# ============================================================

@app.route("/api/patient/lookup", methods=["POST"])
def patient_lookup():
    payload = request.get_json(silent=True) or {}
    lookup_id = str(payload.get("lookup_id") or "").strip()
    id_type = str(payload.get("id_type") or "").strip().upper()

    if not lookup_id or id_type not in VALID_ID_TYPES:
        return error_response("A valid ID number and ID type are required.", 400)

    try:
        with db_cursor() as (_conn, cursor):
            patient = find_patient_by_identifier(cursor, lookup_id, id_type)
    except mysql.connector.Error:
        logger.exception("DB error during patient lookup")
        return internal_error_response()

    if not patient:
        return error_response(
            "We couldn't find your patient details. Please check the number and try again.",
            404,
        )

    return jsonify(
        {
            "success": True,
            "patient": {
                "name": build_patient_name(patient["First_Name"], patient["Last_Name"]),
                "age": compute_age(patient["Date_Of_Birth"]),
                "gender": patient["Gender"],
                "phone": patient["Phone"],
                "address": patient["Address"],
            },
        }
    ), 200


@app.route("/api/patient/case-history", methods=["POST"])
def patient_case_history():
    payload = request.get_json(silent=True) or {}
    lookup_id = str(payload.get("lookup_id") or "").strip()
    id_type = str(payload.get("id_type") or "").strip().upper()
    case_history = payload.get("case_history")

    if not lookup_id or id_type not in VALID_ID_TYPES:
        return error_response("A valid ID number and ID type are required.", 400)

    if not isinstance(case_history, dict):
        return error_response("Medical history details are required.", 400)

    # Only accept the known fields; anything else in the payload is ignored
    # rather than blindly inserted.
    history_values = {
        field: str(case_history.get(field) or "").strip()
        for field in PATIENT_HISTORY_FIELDS
    }

    try:
        with db_cursor() as (_conn, cursor):
            patient = find_patient_by_identifier(cursor, lookup_id, id_type)
    except mysql.connector.Error:
        logger.exception("DB error during patient lookup for case-history")
        return internal_error_response()

    if not patient:
        return error_response(
            "We couldn't find your patient details. Please check the number and try again.",
            404,
        )

    patient_id = patient["Patient_Id"]

    try:
        with db_cursor(commit=True) as (_conn, cursor):
            # 1. Create the consultation (the case) for this visit.
            cursor.execute(
                """
                INSERT INTO consultations (Patient_Id, Status, Checked_In_At)
                VALUES (%s, %s, NOW())
                """,
                (patient_id, ACTIVE_CASE_STATUS),
            )
            case_id = cursor.lastrowid

            # 2. Store the submitted history against that case.
            columns = ", ".join(["Case_Id"] + PATIENT_HISTORY_FIELDS)
            placeholders = ", ".join(["%s"] * (len(PATIENT_HISTORY_FIELDS) + 1))
            values = [case_id] + [history_values[f] for f in PATIENT_HISTORY_FIELDS]

            cursor.execute(
                f"INSERT INTO consultation_history ({columns}) VALUES ({placeholders})",
                values,
            )

            # 3. Mark history as submitted.
            cursor.execute(
                "UPDATE consultations SET History_Submitted_At = NOW() WHERE Case_Id = %s",
                (case_id,),
            )

    except mysql.connector.Error:
        logger.exception("DB error during case-history submission")
        return internal_error_response()

    return jsonify({"success": True}), 201


@app.route("/api/patient/new-session", methods=["POST"])
def patient_new_session():
    """
    No-op acknowledgement.

    There is no "session" entity anywhere in the schema — a case is
    already fully created and stored the moment /case-history
    succeeds. This endpoint exists only because the patient frontend
    pings it (and deliberately ignores failures) when the patient
    hits "Finish". Nothing needs to change server-side.
    """
    return jsonify({"success": True}), 200


# ============================================================
# DOCTOR ENDPOINTS
# ============================================================

@app.route("/api/doctor/patients", methods=["GET"])
def doctor_patients():
    try:
        with db_cursor() as (_conn, cursor):
            cursor.execute(
                """
                SELECT
                    p.First_Name,
                    p.Last_Name,
                    p.Date_Of_Birth,
                    p.Gender,
                    c.Checked_In_At,
                    (
                        SELECT pi.Lookup_Id
                        FROM patient_identifiers pi
                        WHERE pi.Patient_Id = p.Patient_Id
                        ORDER BY pi.Identifier_Id ASC
                        LIMIT 1
                    ) AS Lookup_Id
                FROM consultations c
                JOIN patients p ON p.Patient_Id = c.Patient_Id
                WHERE c.Status = %s
                ORDER BY c.Checked_In_At ASC
                """,
                (ACTIVE_CASE_STATUS,),
            )
            rows = cursor.fetchall()
    except mysql.connector.Error:
        logger.exception("DB error while loading doctor queue")
        return internal_error_response()

    patients = [
        {
            "name": build_patient_name(row["First_Name"], row["Last_Name"]),
            "age": compute_age(row["Date_Of_Birth"]),
            "gender": row["Gender"],
            "lookup_id": row["Lookup_Id"],
            "checked_in_at": row["Checked_In_At"].isoformat() if row["Checked_In_At"] else None,
        }
        for row in rows
    ]

    return jsonify({"patients": patients}), 200


@app.route("/api/doctor/patient/<lookup_id>/history", methods=["GET"])
def doctor_patient_history(lookup_id):
    try:
        with db_cursor() as (_conn, cursor):
            patient = find_patient_by_identifier(cursor, lookup_id)
            if not patient:
                return error_response("Patient not found.", 404)

            case = find_active_case_for_patient(cursor, patient["Patient_Id"])
            if not case:
                return error_response("No active case found for this patient.", 404)

            cursor.execute(
                "SELECT * FROM consultation_history WHERE Case_Id = %s",
                (case["Case_Id"],),
            )
            history_row = cursor.fetchone()
    except mysql.connector.Error:
        logger.exception("DB error while loading patient history")
        return internal_error_response()

    if not history_row:
        return error_response("No submitted history found for this patient.", 404)

    # Strip internal-only columns; return everything else (shared +
    # patient-only + doctor-only fields). Doctor-only fields come back
    # as null automatically when unset, since the columns are nullable.
    excluded = {"History_Id", "Case_Id", "Created_At"}
    case_history = {k: v for k, v in history_row.items() if k not in excluded}

    return jsonify({"case_history": case_history}), 200


@app.route("/api/doctor/patient/<lookup_id>/diagnosis", methods=["POST"])
def doctor_patient_diagnosis(lookup_id):
    payload = request.get_json(silent=True) or {}
    diagnosis_data = payload.get("diagnosis")

    if not isinstance(diagnosis_data, dict):
        return error_response("Diagnosis details are required.", 400)

    diagnosis_text = str(diagnosis_data.get("diagnosis") or "").strip()
    doctor_notes = str(diagnosis_data.get("doctor_notes") or "").strip()
    treatment = str(diagnosis_data.get("treatment") or "").strip()

    if not diagnosis_text:
        return error_response("A clinical diagnosis is required.", 400)

    try:
        with db_cursor(commit=True) as (_conn, cursor):
            patient = find_patient_by_identifier(cursor, lookup_id)
            if not patient:
                return error_response("Patient not found.", 404)

            case = find_active_case_for_patient(cursor, patient["Patient_Id"])
            if not case:
                return error_response("No active case found for this patient.", 404)

            case_id = case["Case_Id"]

            cursor.execute(
                """
                INSERT INTO consultation_diagnoses
                    (Case_Id, Doctor_Id, Diagnosis, Doctor_Notes, Treatment)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (case_id, DEFAULT_DOCTOR_ID, diagnosis_text, doctor_notes, treatment),
            )

            cursor.execute(
                """
                UPDATE consultations
                SET Status = 'COMPLETED',
                    Doctor_Id = %s,
                    Diagnosis_Submitted_At = NOW(),
                    Completed_At = NOW()
                WHERE Case_Id = %s
                """,
                (DEFAULT_DOCTOR_ID, case_id),
            )
    except mysql.connector.Error:
        logger.exception("DB error while submitting diagnosis")
        return internal_error_response()

    return jsonify({"success": True}), 200


# ============================================================
# FALLBACK ERROR HANDLERS
# ============================================================

@app.errorhandler(404)
def handle_404(_error):
    return error_response("Not found.", 404)


@app.errorhandler(Exception)
def handle_unexpected_error(error):
    logger.exception("Unhandled server error")
    return internal_error_response()


if __name__ == "__main__":
    app.run(debug=True, port=5000)
