"""
db.py — MySQL connection handling for MediKiosk.

Also holds the small set of hackathon-scope configuration constants
that don't belong scattered through app.py.
"""

import os
from contextlib import contextmanager

import mysql.connector


# ============================================================
# DATABASE CONNECTION CONFIGURATION
# ============================================================
#
# Kept out of source via environment variables where practical
# (per the "keep credentials out of source where practical"
# requirement). Falls back to local dev defaults so the project
# still runs out of the box during the hackathon.

DB_CONFIG = {
    "host": os.environ.get("MEDIKIOSK_DB_HOST", "localhost"),
    "port": int(os.environ.get("MEDIKIOSK_DB_PORT", "3306")),
    "user": os.environ.get("MEDIKIOSK_DB_USER", "medikiosk_app"),
    "password": os.environ.get("MEDIKIOSK_DB_PASSWORD", "medikiosk_dev_pw"),
    "database": os.environ.get("MEDIKIOSK_DB_NAME", "Medikiosk"),
    "autocommit": False,
}


# ============================================================
# HACKATHON-SCOPE CONFIGURATION
# ============================================================
#
# There is no doctor authentication or doctor selection anywhere
# in the current frontend. Every diagnosis submitted through this
# backend is attributed to a single seeded doctor.
#
# This constant is the ONLY place that decision is encoded. To add
# real doctor auth/selection later: replace the value returned here
# with one derived from the authenticated request/session. It is
# referenced in exactly one place in app.py (the diagnosis handler).

DEFAULT_DOCTOR_ID = int(os.environ.get("MEDIKIOSK_DEFAULT_DOCTOR_ID", "1"))


# ============================================================
# CONNECTION HELPERS
# ============================================================

def get_connection():
    """Open a new MySQL connection using DB_CONFIG."""
    return mysql.connector.connect(**DB_CONFIG)


@contextmanager
def db_cursor(commit=False):
    """
    Context manager yielding (connection, dict-cursor).

    Usage:
        with db_cursor(commit=True) as (conn, cursor):
            cursor.execute(...)
            cursor.execute(...)   # multiple statements share one transaction

    - On normal exit: commits if commit=True.
    - On any exception: rolls back, then re-raises so the caller's
      error handling (e.g. Flask route) decides what to tell the client.
    - Always closes the cursor and connection.
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        yield conn, cursor
        if commit:
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cursor.close()
        conn.close()
