/* ======================================================
   MEDIKIOSK — DOCTOR DASHBOARD
   Frontend controller
====================================================== */


/* ======================================================
   API CONFIGURATION
====================================================== */

const API_BASE_URL = "http://127.0.0.1:5000";

const API_TIMEOUT_MS = 15000;


/* ======================================================
   APPLICATION STATE
====================================================== */

const appState = {
    currentScreen: "view-patient-list",

    patients: [],

    selectedPatient: null,
    selectedPatientHistory: null,

    isLoadingPatients: false,
    isLoadingHistory: false,
    isSubmittingDiagnosis: false
};


/* ======================================================
   DOM ELEMENTS
====================================================== */

const views = document.querySelectorAll("main > section");

const patientList =
    document.getElementById("patient-list");

const patientCount =
    document.getElementById("patient-count");

const patientListLoading =
    document.getElementById("patient-list-loading");

const patientListError =
    document.getElementById("patient-list-error");

const patientListEmpty =
    document.getElementById("patient-list-empty");

const refreshPatientsBtn =
    document.getElementById("btn-refresh-patients");

const historyLoading =
    document.getElementById("history-loading");

const historyError =
    document.getElementById("history-error");

const historyContent =
    document.getElementById("history-content");

const diagnosisForm =
    document.getElementById("diagnosis-form");

const diagnosisInput =
    document.getElementById("diagnosis");

const diagnosisError =
    document.getElementById("diagnosis-error");

const submitDiagnosisBtn =
    document.getElementById("btn-submit-diagnosis");


/* ======================================================
   GENERIC API HELPER
====================================================== */

/*
 * Centralized fetch wrapper.
 *
 * This keeps timeout handling and JSON parsing
 * consistent across all Flask API requests.
 */

async function apiRequest(url, options = {}) {

    const controller = new AbortController();

    const timeout = setTimeout(() => {
        controller.abort();
    }, API_TIMEOUT_MS);

    try {

        const response = await fetch(url, {
            ...options,
            signal: controller.signal
        });

        let data = null;

        try {
            data = await response.json();
        } catch {
            data = null;
        }

        if (!response.ok) {

            const message =
                data?.message ||
                data?.error ||
                "Unable to complete the request.";

            const error = new Error(message);

            error.status = response.status;

            throw error;
        }

        return data;

    } catch (error) {

        if (error.name === "AbortError") {

            throw new Error(
                "The request took too long. Please try again."
            );
        }

        if (
            error instanceof TypeError &&
            !navigator.onLine
        ) {

            throw new Error(
                "There is no internet connection. Please try again."
            );
        }

        throw error;

    } finally {

        clearTimeout(timeout);
    }
}


/* ======================================================
   VIEW MANAGEMENT
====================================================== */

function showScreen(screenId) {

    views.forEach((view) => {
        view.classList.add("hidden");
    });

    const targetView =
        document.getElementById(screenId);

    if (!targetView) {
        console.warn(
            `Screen "${screenId}" was not found.`
        );
        return;
    }

    targetView.classList.remove("hidden");

    appState.currentScreen = screenId;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


/* ======================================================
   PATIENT LIST API
====================================================== */

async function fetchPatients() {

    if (appState.isLoadingPatients) {
        return;
    }

    setPatientListLoading(true);
    hidePatientListError();

    try {

        const data = await apiRequest(
            `${API_BASE_URL}/api/doctor/patients`,
            {
                method: "GET",
                headers: {
                    "Accept": "application/json"
                }
            }
        );

        if (!Array.isArray(data?.patients)) {

            throw new Error(
                "Invalid patient queue response."
            );
        }

        appState.patients = data.patients;

        renderPatientList();

    } catch (error) {

        console.error(
            "Patient queue error:",
            error
        );

        showPatientListError();

    } finally {

        setPatientListLoading(false);
    }
}


/* ======================================================
   RENDER PATIENT LIST
====================================================== */

function renderPatientList() {

    if (!patientList) {
        return;
    }

    patientList.innerHTML = "";

    const patients =
        Array.isArray(appState.patients)
            ? appState.patients
            : [];

    if (patientCount) {
        patientCount.textContent =
            patients.length;
    }

    if (patients.length === 0) {

        patientListEmpty?.classList.remove(
            "hidden"
        );

        return;
    }

    patientListEmpty?.classList.add(
        "hidden"
    );

    patients.forEach((patient) => {

        const card =
            createPatientCard(patient);

        patientList.appendChild(card);
    });
}


/* ======================================================
   CREATE PATIENT CARD
====================================================== */

function createPatientCard(patient) {

    const button =
        document.createElement("button");

    button.type = "button";
    button.className = "patient-card";

    const name =
        patient?.name || "Patient";

    const initial =
        name.trim().charAt(0).toUpperCase() || "P";

    const age =
        patient?.age !== undefined &&
            patient?.age !== null
            ? `${patient.age} years`
            : "Age unavailable";

    const gender =
        patient?.gender || "Gender unavailable";

    const patientId =
        getPatientIdentifier(patient) || "—";

    const checkInTime =
        formatTime(
            patient?.checked_in_at ||
            patient?.created_at ||
            patient?.timestamp
        );

    button.innerHTML = `
        <div class="patient-avatar"
             aria-hidden="true">
            ${escapeHtml(initial)}
        </div>

        <div class="patient-card-main">

            <h2>
                ${escapeHtml(name)}
            </h2>

            <p>
                ${escapeHtml(gender)}
                ·
                ${escapeHtml(age)}
            </p>

        </div>

        <div class="patient-card-reference">

            <span>
                Patient ID
            </span>

            <strong>
                ${escapeHtml(patientId)}
            </strong>

        </div>

        <div class="patient-card-time">

            <span>
                Checked In
            </span>

            <strong>
                ${escapeHtml(checkInTime)}
            </strong>

        </div>

        <div class="patient-card-arrow"
             aria-hidden="true">

            <span class="material-symbols-outlined">
                arrow_forward
            </span>

        </div>
    `;

    button.setAttribute(
        "aria-label",
        `Open patient history for ${name}`
    );

    button.addEventListener(
        "click",
        () => openPatientHistory(patient)
    );

    return button;
}


/* ======================================================
   OPEN PATIENT HISTORY
====================================================== */

async function openPatientHistory(patient) {

    if (!patient) {
        return;
    }

    const patientId =
        getPatientIdentifier(patient);

    if (!patientId) {

        console.error(
            "Unable to open patient: missing identifier."
        );

        showHistoryError();

        return;
    }

    /*
     * Store a shallow copy so later queue refreshes
     * don't unexpectedly mutate the selected patient.
     */

    appState.selectedPatient = {
        ...patient
    };

    appState.selectedPatientHistory = null;

    updateHistoryPatientHeader(patient);

    clearHistoryFields();

    hideHistoryError();

    historyContent?.classList.add("hidden");
    historyLoading?.classList.remove("hidden");

    showScreen("view-patient-history");

    await fetchPatientHistory(patientId);
}


/* ======================================================
   PATIENT HISTORY API
====================================================== */

async function fetchPatientHistory(patientId) {

    if (!patientId) {

        showHistoryError();

        return;
    }

    if (appState.isLoadingHistory) {
        return;
    }

    appState.isLoadingHistory = true;

    try {

        const data = await apiRequest(
            `${API_BASE_URL}/api/doctor/patient/${encodeURIComponent(patientId)}/history`,
            {
                method: "GET",
                headers: {
                    "Accept": "application/json"
                }
            }
        );

        /*
         * Make sure the selected patient hasn't changed
         * while the request was in flight.
         */

        const currentlySelectedId =
            getPatientIdentifier(
                appState.selectedPatient
            );

        if (
            currentlySelectedId !== patientId
        ) {
            return;
        }

        const history =
            data?.case_history ||
            data?.history ||
            null;

        if (!history) {

            throw new Error(
                "Patient history was not found."
            );
        }

        appState.selectedPatientHistory =
            history;

        renderPatientHistory(history);

        historyLoading?.classList.add(
            "hidden"
        );

        historyContent?.classList.remove(
            "hidden"
        );

    } catch (error) {

        console.error(
            "Patient history error:",
            error
        );

        historyLoading?.classList.add(
            "hidden"
        );

        showHistoryError();

    } finally {

        appState.isLoadingHistory = false;
    }
}


/* ======================================================
   UPDATE HISTORY PATIENT HEADER
====================================================== */

function updateHistoryPatientHeader(patient) {

    if (!patient) {
        return;
    }

    const name =
        patient.name || "Patient";

    const gender =
        patient.gender || "—";

    const age =
        patient.age !== undefined &&
            patient.age !== null
            ? `${patient.age} years`
            : "—";

    const patientId =
        getPatientIdentifier(patient);

    const initial =
        name.trim().charAt(0).toUpperCase() || "P";

    const avatar =
        document.getElementById(
            "history-avatar"
        );

    const nameElement =
        document.getElementById(
            "history-patient-name"
        );

    const basicElement =
        document.getElementById(
            "history-patient-basic"
        );

    const idElement =
        document.getElementById(
            "history-patient-id"
        );

    if (avatar) {
        avatar.textContent = initial;
    }

    if (nameElement) {
        nameElement.textContent = name;
    }

    if (basicElement) {
        basicElement.textContent =
            `${gender} · ${age}`;
    }

    if (idElement) {
        idElement.textContent =
            patientId || "—";
    }
}


/* ======================================================
   RENDER PATIENT HISTORY
====================================================== */

function renderPatientHistory(history) {

    if (!history) {
        return;
    }

    const historyMap = {

        "history-chief-complaint":
            history.chief_complaint,

        "history-duration":
            history.duration,

        "history-severity":
            history.symptom_severity,

        "history-symptoms-description":
            history.symptoms_description,

        "history-symptom-changes":
            history.symptom_changes,

        "history-relieving-factors":
            history.relieving_factors,

        "history-aggravating-factors":
            history.aggravating_factors,

        "history-other-symptoms":
            history.other_symptoms,

        "history-past-medical":
            history.past_medical_history,

        "history-hospital-admissions":
            history.hospital_admissions,

        "history-surgeries":
            history.surgeries,

        "history-previous-similar":
            history.previous_similar_symptoms,

        "history-medications":
            history.current_medications,

        "history-allergies":
            history.allergies,

        "history-medication-reactions":
            history.medication_reactions,

        "history-family":
            history.family_history,

        "history-additional-family":
            history.additional_family_information,

        "history-diet":
            history.diet,

        "history-physical-activity":
            history.physical_activity,

        "history-lifestyle":
            history.lifestyle_information
    };

    Object.entries(historyMap)
        .forEach(([elementId, value]) => {

            setHistoryValue(
                elementId,
                value
            );
        });
}


/* ======================================================
   SET HISTORY VALUE
====================================================== */

function setHistoryValue(elementId, value) {

    const element =
        document.getElementById(elementId);

    if (!element) {
        return;
    }

    if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
    ) {

        element.textContent =
            "Not provided";

        return;
    }

    element.textContent =
        String(value);
}


/* ======================================================
   CLEAR HISTORY FIELDS
====================================================== */

function clearHistoryFields() {

    const historyFields =
        document.querySelectorAll(
            ".history-field p"
        );

    historyFields.forEach((field) => {

        field.textContent = "—";
    });
}


/* ======================================================
   OPEN DIAGNOSIS
====================================================== */

function openDiagnosis() {

    if (!appState.selectedPatient) {

        console.warn(
            "Cannot open diagnosis without a selected patient."
        );

        return;
    }

    populateDiagnosisHeader();

    clearDiagnosisForm();

    showScreen("view-diagnosis");
}


/* ======================================================
   POPULATE DIAGNOSIS HEADER
====================================================== */

function populateDiagnosisHeader() {

    const patient =
        appState.selectedPatient;

    if (!patient) {
        return;
    }

    const name =
        patient.name || "Patient";

    const patientId =
        getPatientIdentifier(patient);

    const initial =
        name.trim().charAt(0).toUpperCase() || "P";

    const avatar =
        document.getElementById(
            "diagnosis-avatar"
        );

    const nameElement =
        document.getElementById(
            "diagnosis-patient-name"
        );

    const referenceElement =
        document.getElementById(
            "diagnosis-patient-reference"
        );

    if (avatar) {
        avatar.textContent = initial;
    }

    if (nameElement) {
        nameElement.textContent = name;
    }

    if (referenceElement) {
        referenceElement.textContent =
            `Patient ID: ${patientId || "—"}`;
    }
}


/* ======================================================
   DIAGNOSIS VALIDATION
====================================================== */

function validateDiagnosisForm() {

    if (!diagnosisInput) {
        return false;
    }

    const diagnosis =
        diagnosisInput.value.trim();

    if (!diagnosis) {

        diagnosisInput.classList.add(
            "error-border"
        );

        diagnosisInput.setAttribute(
            "aria-invalid",
            "true"
        );

        diagnosisError?.classList.remove(
            "hidden"
        );

        diagnosisInput.focus();

        return false;
    }

    diagnosisInput.classList.remove(
        "error-border"
    );

    diagnosisInput.setAttribute(
        "aria-invalid",
        "false"
    );

    diagnosisError?.classList.add(
        "hidden"
    );

    return true;
}


/* ======================================================
   COLLECT DIAGNOSIS
====================================================== */

function collectDiagnosisData() {

    const doctorNotesInput =
        document.getElementById(
            "doctor-notes"
        );

    const treatmentInput =
        document.getElementById(
            "treatment"
        );

    return {

        diagnosis:
            diagnosisInput?.value.trim() || "",

        doctor_notes:
            doctorNotesInput?.value.trim() || "",

        treatment:
            treatmentInput?.value.trim() || ""
    };
}


/* ======================================================
   SUBMIT DIAGNOSIS
====================================================== */

async function submitDiagnosis(event) {

    event?.preventDefault();

    if (appState.isSubmittingDiagnosis) {
        return;
    }

    if (!validateDiagnosisForm()) {
        return;
    }

    const patient =
        appState.selectedPatient;

    if (!patient) {

        console.error(
            "No patient selected."
        );

        return;
    }

    const patientId =
        getPatientIdentifier(patient);

    if (!patientId) {

        console.error(
            "Patient identifier missing."
        );

        return;
    }

    const diagnosisData =
        collectDiagnosisData();

    appState.isSubmittingDiagnosis = true;

    if (submitDiagnosisBtn) {
        submitDiagnosisBtn.disabled = true;
    }

    showScreen(
        "view-diagnosis-loading"
    );

    try {

        await apiRequest(
            `${API_BASE_URL}/api/doctor/patient/${encodeURIComponent(patientId)}/diagnosis`,
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json",

                    "Accept":
                        "application/json"
                },

                body: JSON.stringify({
                    diagnosis: diagnosisData
                })
            }
        );

        /*
         * IMPORTANT:
         *
         * The backend should mark this patient's
         * consultation as completed.
         *
         * We do not delete anything locally.
         * We simply clear the selected frontend state
         * and refresh the queue from Flask.
         */

        clearCurrentPatientSession();

        await fetchPatients();

        showScreen(
            "view-patient-list"
        );

    } catch (error) {

        console.error(
            "Diagnosis submission error:",
            error
        );

        /*
         * Do NOT clear diagnosis fields here.
         *
         * This allows the doctor to retry safely.
         */

        showScreen(
            "view-diagnosis-error"
        );

    } finally {

        appState.isSubmittingDiagnosis = false;

        if (submitDiagnosisBtn) {
            submitDiagnosisBtn.disabled = false;
        }
    }
}


/* ======================================================
   OPTIONAL SESSION COMPLETION
====================================================== */

/*
 * Use this only if the Flask backend uses a
 * separate completion endpoint.
 *
 * Normally the diagnosis POST should itself
 * complete the consultation.
 */

async function notifyPatientSessionComplete(
    patientId
) {

    if (!patientId) {
        return;
    }

    try {

        await apiRequest(
            `${API_BASE_URL}/api/doctor/patient/${encodeURIComponent(patientId)}/complete`,
            {
                method: "POST",

                headers: {
                    "Accept":
                        "application/json"
                }
            }
        );

    } catch (error) {

        console.error(
            "Unable to notify session completion:",
            error
        );
    }
}


/* ======================================================
   CLEAR DIAGNOSIS FORM
====================================================== */

function clearDiagnosisForm() {

    if (!diagnosisForm) {
        return;
    }

    diagnosisForm.reset();

    if (diagnosisInput) {

        diagnosisInput.classList.remove(
            "error-border"
        );

        diagnosisInput.setAttribute(
            "aria-invalid",
            "false"
        );
    }

    diagnosisError?.classList.add(
        "hidden"
    );
}


/* ======================================================
   CLEAR CURRENT PATIENT SESSION
====================================================== */

function clearCurrentPatientSession() {

    appState.selectedPatient =
        null;

    appState.selectedPatientHistory =
        null;

    appState.isSubmittingDiagnosis =
        false;
}


/* ======================================================
   RETURN TO PATIENT LIST
====================================================== */

function returnToPatientList() {

    clearCurrentPatientSession();

    clearDiagnosisForm();

    hideHistoryError();

    historyLoading?.classList.add(
        "hidden"
    );

    historyContent?.classList.add(
        "hidden"
    );

    showScreen(
        "view-patient-list"
    );
}


/* ======================================================
   PATIENT IDENTIFIER
====================================================== */

function getPatientIdentifier(patient) {

    if (!patient) {
        return "";
    }

    return String(
        patient.lookup_id ||
        patient.patient_id ||
        patient.id ||
        ""
    ).trim();
}


/* ======================================================
   LOADING STATE
====================================================== */

function setPatientListLoading(
    isLoading
) {

    appState.isLoadingPatients =
        isLoading;

    if (
        !patientListLoading ||
        !patientList
    ) {
        return;
    }

    if (isLoading) {

        patientListLoading.classList.remove(
            "hidden"
        );

        patientList.classList.add(
            "hidden"
        );

        patientListEmpty?.classList.add(
            "hidden"
        );

    } else {

        patientListLoading.classList.add(
            "hidden"
        );

        patientList.classList.remove(
            "hidden"
        );
    }
}


/* ======================================================
   PATIENT LIST ERROR
====================================================== */

function showPatientListError() {

    patientListError?.classList.remove(
        "hidden"
    );

    patientList?.classList.add(
        "hidden"
    );

    patientListEmpty?.classList.add(
        "hidden"
    );
}


function hidePatientListError() {

    patientListError?.classList.add(
        "hidden"
    );
}


/* ======================================================
   HISTORY ERROR
====================================================== */

function showHistoryError() {

    historyError?.classList.remove(
        "hidden"
    );

    historyContent?.classList.add(
        "hidden"
    );
}


function hideHistoryError() {

    historyError?.classList.add(
        "hidden"
    );
}


/* ======================================================
   FORMAT TIME
====================================================== */

function formatTime(timestamp) {

    if (!timestamp) {
        return "Recently";
    }

    const date =
        new Date(timestamp);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "Recently";
    }

    return date.toLocaleTimeString(
        [],
        {
            hour: "2-digit",
            minute: "2-digit"
        }
    );
}


/* ======================================================
   HTML ESCAPING
====================================================== */

function escapeHtml(value) {

    return String(value)
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );
}


/* ======================================================
   EVENT LISTENERS
====================================================== */


/*
 * Refresh patient queue
 */

if (refreshPatientsBtn) {

    refreshPatientsBtn.addEventListener(
        "click",
        fetchPatients
    );
}


/*
 * Back to patient list
 */

const backToPatientsBtn =
    document.getElementById(
        "btn-back-to-patients"
    );

const historyBackBtn =
    document.getElementById(
        "btn-history-back"
    );

if (backToPatientsBtn) {

    backToPatientsBtn.addEventListener(
        "click",
        returnToPatientList
    );
}

if (historyBackBtn) {

    historyBackBtn.addEventListener(
        "click",
        returnToPatientList
    );
}


/*
 * Continue from history to diagnosis
 */

const openDiagnosisBtn =
    document.getElementById(
        "btn-open-diagnosis"
    );

if (openDiagnosisBtn) {

    openDiagnosisBtn.addEventListener(
        "click",
        openDiagnosis
    );
}


/*
 * Back from diagnosis to history
 */

const backToHistoryBtn =
    document.getElementById(
        "btn-back-to-history"
    );

if (backToHistoryBtn) {

    backToHistoryBtn.addEventListener(
        "click",
        () => {

            if (
                !appState.selectedPatient
            ) {
                returnToPatientList();
                return;
            }

            showScreen(
                "view-patient-history"
            );
        }
    );
}


/*
 * Diagnosis form submission
 */

if (diagnosisForm) {

    diagnosisForm.addEventListener(
        "submit",
        submitDiagnosis
    );
}


/*
 * Remove diagnosis error while typing
 */

if (diagnosisInput) {

    diagnosisInput.addEventListener(
        "input",
        () => {

            if (
                diagnosisInput.value.trim()
            ) {

                diagnosisInput.classList.remove(
                    "error-border"
                );

                diagnosisInput.setAttribute(
                    "aria-invalid",
                    "false"
                );

                diagnosisError?.classList.add(
                    "hidden"
                );
            }
        }
    );
}


/*
 * Retry diagnosis submission
 */

const retryDiagnosisBtn =
    document.getElementById(
        "btn-diagnosis-retry"
    );

if (retryDiagnosisBtn) {

    retryDiagnosisBtn.addEventListener(
        "click",
        () => {

            submitDiagnosis();
        }
    );
}


/*
 * Review diagnosis
 */

const reviewDiagnosisBtn =
    document.getElementById(
        "btn-diagnosis-review"
    );

if (reviewDiagnosisBtn) {

    reviewDiagnosisBtn.addEventListener(
        "click",
        () => {

            if (
                !appState.selectedPatient
            ) {

                returnToPatientList();

                return;
            }

            showScreen(
                "view-diagnosis"
            );
        }
    );
}


/* ======================================================
   KEYBOARD / ACCESSIBILITY
====================================================== */

document.addEventListener(
    "keydown",
    (event) => {

        /*
         * Escape returns the doctor to the queue
         * when they are viewing a patient.
         */

        if (
            event.key === "Escape" &&
            appState.currentScreen !==
            "view-patient-list"
        ) {

            returnToPatientList();
        }
    }
);


/* ======================================================
   INITIAL APPLICATION START
====================================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        showScreen(
            "view-patient-list"
        );

        fetchPatients();
    }
);
