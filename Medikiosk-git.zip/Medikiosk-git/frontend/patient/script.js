// ============================================================
// MEDIKIOSK — PATIENT FRONTEND
// Flask backend integration
// ============================================================


// ============================================================
// API CONFIGURATION
// ============================================================

const API_BASE_URL = "http://127.0.0.1:5000";


// ============================================================
// APPLICATION STATE
// ============================================================

const appState = {
    patientId: "",
    idType: "AADHAAR",
    patient: null,
    currentScreen: "view-welcome",
    isLookingUp: false,
    isSubmitting: false
};


// ============================================================
// DOM ELEMENTS
// ============================================================

const sections = document.querySelectorAll("main > section");

const idTypeInput = document.getElementById("id-type");
const idInput = document.getElementById("id-number");
const idError = document.getElementById("id-error-msg");
const getStartedBtn = document.getElementById("btn-get-started");

const lookupRetryBtn =
    document.getElementById("btn-lookup-retry");

const lookupFailureMessage =
    document.getElementById("lookup-failure-message");

const bioInitial =
    document.getElementById("bio-initial");

const bioName =
    document.getElementById("bio-name");

const bioBasic =
    document.getElementById("bio-basic");

const bioPhone =
    document.getElementById("bio-phone");

const bioAddress =
    document.getElementById("bio-address");

const bioPhoneContainer =
    document.getElementById("bio-phone-container");

const bioAddressContainer =
    document.getElementById("bio-address-container");

const confirmPatientBtn =
    document.getElementById("btn-confirm-patient");

const rejectPatientBtn =
    document.getElementById("btn-reject-patient");

const backBiodataBtn =
    document.getElementById("btn-back-biodata");

const clinicalForm =
    document.getElementById("clinical-form");

const submitHistoryBtn =
    document.getElementById("btn-submit-history");

const retrySubmitBtn =
    document.getElementById("btn-retry-submit");

const reviewFormBtn =
    document.getElementById("btn-review-form");

const finishBtn =
    document.getElementById("btn-finish");


// ============================================================
// SCREEN MANAGEMENT
// ============================================================

function switchView(viewId) {

    sections.forEach((section) => {
        section.classList.add("hidden");
    });

    const targetView =
        document.getElementById(viewId);

    if (!targetView) {
        return;
    }

    targetView.classList.remove("hidden");

    appState.currentScreen = viewId;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


// ============================================================
// INPUT VALIDATION
// ============================================================

function sanitizeNumericInput(value) {

    return value.replace(/\D/g, "");
}


function isValidPatientId(value) {

    const id = value.trim();

    /*
     * The frontend deliberately does not attempt to authenticate
     * Aadhaar or ABHA credentials.
     *
     * It only ensures that the entered value is numeric and
     * non-empty before sending it to Flask.
     *
     * The backend remains responsible for actual verification.
     */

    return /^\d{8,18}$/.test(id);
}


function validatePatientId() {

    if (!idInput) {
        return false;
    }

    const id =
        sanitizeNumericInput(idInput.value.trim());

    idInput.value = id;

    if (!isValidPatientId(id)) {

        showIdError(
            "Please enter a valid ID number."
        );

        return false;
    }

    clearIdError();

    return true;
}


function showIdError(message) {

    if (!idInput) {
        return;
    }

    idInput.classList.add("error-border");

    if (idError) {
        idError.textContent = message;
        idError.classList.remove("hidden");
    }
}


function clearIdError() {

    if (!idInput) {
        return;
    }

    idInput.classList.remove("error-border");

    if (idError) {
        idError.classList.add("hidden");
    }
}


// ============================================================
// UPDATE GET STARTED BUTTON
// ============================================================

function updateGetStartedButton() {

    if (!getStartedBtn || !idInput) {
        return;
    }

    const id =
        sanitizeNumericInput(idInput.value.trim());

    getStartedBtn.disabled =
        !isValidPatientId(id) ||
        appState.isLookingUp;
}


// ============================================================
// PATIENT LOOKUP API
// ============================================================

async function lookupPatient() {

    if (appState.isLookingUp) {
        return;
    }

    if (!validatePatientId()) {
        return;
    }

    const patientId =
        idInput.value.trim();

    const idType =
        idTypeInput
            ? idTypeInput.value
            : "AADHAAR";


    appState.patientId = patientId;
    appState.idType = idType;
    appState.isLookingUp = true;

    updateGetStartedButton();

    showLookupLoadingState();

    try {

        const response = await fetch(
            `${API_BASE_URL}/api/patient/lookup`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    lookup_id: patientId,
                    id_type: idType
                })
            }
        );


        let data = {};

        try {
            data = await response.json();
        } catch (error) {
            data = {};
        }


        if (!response.ok) {

            const error =
                new Error(
                    data.message ||
                    "Unable to verify patient details."
                );

            error.status =
                response.status;

            throw error;
        }


        if (
            !data ||
            data.success === false ||
            !data.patient
        ) {

            throw new Error(
                "We were unable to find your patient details."
            );
        }


        appState.patient =
            data.patient;


        renderPatientDetails(
            appState.patient
        );


        switchView(
            "view-biodata"
        );


    } catch (error) {

        console.error(
            "Patient lookup error:",
            error
        );


        let message =
            "We were unable to verify your details. Please check the number and try again.";


        if (
            error.status === 404
        ) {

            message =
                "We couldn't find your patient details. Please check the number and try again.";

        } else if (
            error.status >= 500
        ) {

            message =
                "We couldn't verify your details right now. Please try again.";

        } else if (
            error instanceof TypeError
        ) {

            message =
                "We couldn't connect right now. Please try again.";

        }


        showLookupFailure(
            message
        );


    } finally {

        appState.isLookingUp = false;

        updateGetStartedButton();
    }
}


// ============================================================
// LOOKUP LOADING STATE
// ============================================================

function showLookupLoadingState() {

    /*
     * Reuse the existing loading screen.
     */

    const loadingTitle =
        document.querySelector(
            "#view-loading h2"
        );

    const loadingDescription =
        document.querySelector(
            "#view-loading .status-description"
        );


    if (loadingTitle) {
        loadingTitle.textContent =
            "Checking your details...";
    }


    if (loadingDescription) {
        loadingDescription.textContent =
            "Please wait a moment.";
    }


    switchView(
        "view-loading"
    );
}


// ============================================================
// LOOKUP FAILURE
// ============================================================

function showLookupFailure(message) {

    if (lookupFailureMessage) {
        lookupFailureMessage.textContent =
            message;
    }

    switchView(
        "view-lookup-failure"
    );
}


// ============================================================
// RENDER PATIENT DETAILS
// ============================================================

function renderPatientDetails(patient) {

    if (!patient) {
        return;
    }


    const name =
        patient.name ||
        "Patient";


    const gender =
        patient.gender ||
        "";


    const age =
        patient.age !== undefined &&
            patient.age !== null
            ? `${patient.age} years`
            : "";


    const phone =
        patient.phone ||
        patient.mobile ||
        "";


    const address =
        patient.address ||
        "";


    const initial =
        name
            .trim()
            .charAt(0)
            .toUpperCase() ||
        "P";


    if (bioInitial) {
        bioInitial.textContent =
            initial;
    }


    if (bioName) {
        bioName.textContent =
            name;
    }


    if (bioBasic) {

        const basicDetails =
            [gender, age]
                .filter(Boolean)
                .join(", ");

        bioBasic.textContent =
            basicDetails || "—";
    }


    if (bioPhone) {

        bioPhone.textContent =
            phone || "Not available";
    }


    if (bioAddress) {

        bioAddress.textContent =
            address || "Not available";
    }


    if (bioPhoneContainer) {

        bioPhoneContainer.classList.toggle(
            "hidden",
            !phone
        );
    }


    if (bioAddressContainer) {

        bioAddressContainer.classList.toggle(
            "hidden",
            !address
        );
    }
}


// ============================================================
// CONFIRM PATIENT
// ============================================================

if (confirmPatientBtn) {

    confirmPatientBtn.addEventListener(
        "click",
        () => {

            if (!appState.patient) {
                return;
            }

            clearClinicalFormValidation();

            switchView(
                "view-history"
            );
        }
    );
}


// ============================================================
// REJECT PATIENT
// ============================================================

function rejectPatient() {

    resetPatientSession();

    switchView(
        "view-welcome"
    );

    focusPatientIdInput();
}


if (rejectPatientBtn) {

    rejectPatientBtn.addEventListener(
        "click",
        rejectPatient
    );
}


// ============================================================
// LOOKUP RETRY
// ============================================================

if (lookupRetryBtn) {

    lookupRetryBtn.addEventListener(
        "click",
        () => {

            switchView(
                "view-welcome"
            );

            focusPatientIdInput();
        }
    );
}


// ============================================================
// PATIENT ID INPUT
// ============================================================

if (idInput) {

    idInput.addEventListener(
        "input",
        () => {

            const sanitized =
                sanitizeNumericInput(
                    idInput.value
                );

            idInput.value =
                sanitized;

            clearIdError();

            updateGetStartedButton();
        }
    );


    idInput.addEventListener(
        "blur",
        () => {

            if (
                idInput.value.trim() !== ""
            ) {
                validatePatientId();
            }
        }
    );


    idInput.addEventListener(
        "keydown",
        (event) => {

            if (
                event.key === "Enter" &&
                !getStartedBtn.disabled
            ) {

                event.preventDefault();

                lookupPatient();
            }
        }
    );
}


// ============================================================
// ID TYPE
// ============================================================

if (idTypeInput) {

    idTypeInput.addEventListener(
        "change",
        () => {

            appState.idType =
                idTypeInput.value;

            clearIdError();
        }
    );
}


// ============================================================
// FORM FIELD CONFIGURATION
// ============================================================

const formFields = [

    "chief_complaint",
    "duration",
    "symptom_changes",
    "past_medical_history",
    "current_medications",
    "allergies",
    "surgeries",
    "hospital_admissions",
    "family_history",
    "lifestyle_information",
    "diet",
    "physical_activity",
    "sleep",
    "mental_emotional_wellbeing",
    "immunization_history",
    "recent_medical_tests",
    "additional_health_information",
    "previous_diagnoses",
    "patient_concerns"

];


// ============================================================
// FORM VALIDATION
// ============================================================

function getFormFields() {

    if (!clinicalForm) {
        return [];
    }

    return formFields
        .map(
            (fieldName) =>
                clinicalForm.elements[fieldName]
        )
        .filter(Boolean);
}


function validateField(field) {

    if (!field) {
        return true;
    }


    const errorElement =
        document.getElementById(
            `${field.id}-error`
        );


    const isValid =
        field.value.trim() !== "";


    if (!isValid) {

        field.classList.add(
            "error-border"
        );


        if (errorElement) {

            errorElement.classList.remove(
                "hidden"
            );
        }


        return false;
    }


    field.classList.remove(
        "error-border"
    );


    if (errorElement) {

        errorElement.classList.add(
            "hidden"
        );
    }


    return true;
}


function validateClinicalForm() {

    const fields =
        getFormFields();


    let isValid =
        true;


    let firstInvalidField =
        null;


    fields.forEach(
        (field) => {

            const fieldValid =
                validateField(field);


            if (!fieldValid) {

                isValid =
                    false;


                if (!firstInvalidField) {

                    firstInvalidField =
                        field;
                }
            }
        }
    );


    if (firstInvalidField) {

        firstInvalidField.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });


        setTimeout(
            () => {
                firstInvalidField.focus();
            },
            300
        );
    }


    return isValid;
}


// ============================================================
// LIVE VALIDATION
// ============================================================

function initializeLiveValidation() {

    const fields =
        getFormFields();


    fields.forEach(
        (field) => {

            field.addEventListener(
                "input",
                () => {

                    if (
                        field.value.trim() !== ""
                    ) {

                        field.classList.remove(
                            "error-border"
                        );


                        const errorElement =
                            document.getElementById(
                                `${field.id}-error`
                            );


                        if (errorElement) {

                            errorElement.classList.add(
                                "hidden"
                            );
                        }
                    }
                }
            );
        }
    );
}


// ============================================================
// COLLECT CASE HISTORY
// ============================================================

function collectCaseHistory() {

    const caseHistory = {};


    formFields.forEach(
        (fieldName) => {

            const field =
                clinicalForm.elements[fieldName];


            if (field) {

                caseHistory[fieldName] =
                    field.value.trim();
            }
        }
    );


    return caseHistory;
}


// ============================================================
// CASE HISTORY API
// ============================================================

async function submitCaseHistory() {

    if (appState.isSubmitting) {
        return;
    }


    if (!appState.patientId) {

        console.error(
            "Patient identifier is missing."
        );

        return;
    }


    if (!validateClinicalForm()) {
        return;
    }


    const caseHistory =
        collectCaseHistory();


    appState.isSubmitting =
        true;


    if (submitHistoryBtn) {

        submitHistoryBtn.disabled =
            true;
    }


    showSubmissionLoading();


    try {

        const response =
            await fetch(
                `${API_BASE_URL}/api/patient/case-history`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        lookup_id:
                            appState.patientId,

                        id_type:
                            appState.idType,

                        case_history:
                            caseHistory
                    })
                }
            );


        let data = {};


        try {

            data =
                await response.json();

        } catch (error) {

            data = {};
        }


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Unable to save medical history."
            );
        }


        if (
            data.success === false
        ) {

            throw new Error(
                data.message ||
                "Unable to save medical history."
            );
        }


        switchView(
            "view-success"
        );


    } catch (error) {

        console.error(
            "Medical history submission error:",
            error
        );


        showSubmissionFailure(
            getPatientFriendlySubmissionError(
                error
            )
        );


    } finally {

        appState.isSubmitting =
            false;


        if (submitHistoryBtn) {

            submitHistoryBtn.disabled =
                false;
        }
    }
}


// ============================================================
// PATIENT-FRIENDLY SUBMISSION ERROR
// ============================================================

function getPatientFriendlySubmissionError(error) {

    if (
        error instanceof TypeError
    ) {

        return (
            "We couldn't connect right now. " +
            "Please try again. Your entered information has been preserved."
        );
    }


    return (
        "We couldn't save your medical history. " +
        "Please try again. Your entered information has been preserved."
    );
}


// ============================================================
// SUBMISSION LOADING
// ============================================================

function showSubmissionLoading() {

    const loadingTitle =
        document.querySelector(
            "#view-loading h2"
        );


    const loadingDescription =
        document.querySelector(
            "#view-loading .status-description"
        );


    if (loadingTitle) {

        loadingTitle.textContent =
            "Saving your medical history...";
    }


    if (loadingDescription) {

        loadingDescription.textContent =
            "Please wait a moment.";
    }


    switchView(
        "view-loading"
    );
}


// ============================================================
// SUBMISSION FAILURE
// ============================================================

function showSubmissionFailure(message) {

    const failureMessage =
        document.getElementById(
            "submit-failure-message"
        );


    if (failureMessage) {

        failureMessage.textContent =
            message;
    }


    switchView(
        "view-submit-failure"
    );
}


// ============================================================
// CLINICAL FORM SUBMISSION
// ============================================================

if (clinicalForm) {

    clinicalForm.addEventListener(
        "submit",
        (event) => {

            event.preventDefault();

            submitCaseHistory();
        }
    );
}


// ============================================================
// BACK TO BIODATA
// ============================================================

if (backBiodataBtn) {

    backBiodataBtn.addEventListener(
        "click",
        () => {

            if (appState.isSubmitting) {
                return;
            }

            switchView(
                "view-biodata"
            );
        }
    );
}


// ============================================================
// REVIEW FORM AFTER FAILED SUBMISSION
// ============================================================

if (reviewFormBtn) {

    reviewFormBtn.addEventListener(
        "click",
        () => {

            switchView(
                "view-history"
            );
        }
    );
}


// ============================================================
// RETRY SUBMISSION
// ============================================================

if (retrySubmitBtn) {

    retrySubmitBtn.addEventListener(
        "click",
        () => {

            submitCaseHistory();
        }
    );
}


// ============================================================
// CLEAR FORM VALIDATION
// ============================================================

function clearClinicalFormValidation() {

    const fields =
        getFormFields();


    fields.forEach(
        (field) => {

            field.classList.remove(
                "error-border"
            );


            const errorElement =
                document.getElementById(
                    `${field.id}-error`
                );


            if (errorElement) {

                errorElement.classList.add(
                    "hidden"
                );
            }
        }
    );
}


// ============================================================
// RESET PATIENT SESSION
// ============================================================

function resetPatientSession() {

    appState.patientId =
        "";

    appState.idType =
        "AADHAAR";

    appState.patient =
        null;

    appState.isLookingUp =
        false;

    appState.isSubmitting =
        false;


    if (idInput) {

        idInput.value =
            "";

        idInput.classList.remove(
            "error-border"
        );
    }


    if (idTypeInput) {

        idTypeInput.value =
            "AADHAAR";
    }


    clearIdError();


    if (clinicalForm) {

        clinicalForm.reset();
    }


    clearClinicalFormValidation();


    if (bioInitial) {
        bioInitial.textContent =
            "P";
    }


    if (bioName) {
        bioName.textContent =
            "Patient";
    }


    if (bioBasic) {
        bioBasic.textContent =
            "—";
    }


    if (bioPhone) {
        bioPhone.textContent =
            "—";
    }


    if (bioAddress) {
        bioAddress.textContent =
            "—";
    }


    if (bioPhoneContainer) {

        bioPhoneContainer.classList.remove(
            "hidden"
        );
    }


    if (bioAddressContainer) {

        bioAddressContainer.classList.remove(
            "hidden"
        );
    }


    if (submitHistoryBtn) {

        submitHistoryBtn.disabled =
            false;
    }


    updateGetStartedButton();
}


// ============================================================
// FINISH / NEW SESSION
// ============================================================

async function startNewSession() {

    const previousPatientId =
        appState.patientId;


    /*
     * Optional notification to Flask.
     *
     * Failure here must NOT prevent the frontend
     * from starting a fresh session.
     */

    if (previousPatientId) {

        try {

            await fetch(
                `${API_BASE_URL}/api/patient/new-session`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        lookup_id:
                            previousPatientId
                    })
                }
            );

        } catch (error) {

            console.warn(
                "Unable to notify new session:",
                error
            );
        }
    }


    resetPatientSession();


    switchView(
        "view-welcome"
    );


    focusPatientIdInput();
}


// ============================================================
// FINISH BUTTON
// ============================================================

if (finishBtn) {

    finishBtn.addEventListener(
        "click",
        startNewSession
    );
}


// ============================================================
// FOCUS ID INPUT
// ============================================================

function focusPatientIdInput() {

    setTimeout(
        () => {

            if (idInput) {

                idInput.focus();
            }

        },
        250
    );
}


// ============================================================
// INITIALIZE
// ============================================================

function initializeApplication() {

    initializeLiveValidation();

    resetPatientSession();

    switchView(
        "view-welcome"
    );

    focusPatientIdInput();
}


initializeApplication();

// GET STARTED BUTTON
if (getStartedBtn) {
    getStartedBtn.addEventListener("click", lookupPatient);
}

